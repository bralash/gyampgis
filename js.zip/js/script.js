$(document).ready(function() {
	$('select.ui.dropdown').dropdown();
});